<?php
$defaultTheme = (isset($envVariables) && isset($envVariables['DEFAULT_THEME'])) ? $envVariables['DEFAULT_THEME'] : 'theme-red';
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Çekirdeği - GitHub Paneli</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="themes/jarvis/assets/css/style.css">

    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="icon" type="image/svg+xml" href="icon0.svg">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="manifest" href="manifest.json">
</head>

<body class="<?= htmlspecialchars($defaultTheme) ?>">


    <!-- HUD Background Lines -->
    <div class="hud-bg"></div>
    <div class="hud-scanline"></div>

    <div class="hud-container">

        <!-- Arc Reactor Core -->
        <div class="reactor-section">
            <div class="tech-line left-tech"></div>
            <div class="arc-reactor">
                <div class="ring ring-outer"></div>
                <div class="ring ring-middle"></div>
                <div class="ring ring-inner">
                    <div class="reactor-core"></div>
                </div>
            </div>
            <div class="tech-line right-tech"></div>
        </div>

        <div class="system-status">
            <span class="status-text">Github Activity Dasboard</span>
            <span class="status-pulse"></span>
        </div>

        <!-- Long Term Stats (HUD Panels) -->
        <section class="stats-grid" id="longTermStatsSection" style="display: none;">
            <div class="hud-panel stat-box">
                <div class="panel-corner top-left"></div>
                <div class="panel-corner bottom-right"></div>
                <h3 class="stats-title">Haftalık Katkı</h3>
                <strong class="stat-value" id="statWeekly">0</strong>
            </div>
            <div class="hud-panel stat-box">
                <div class="panel-corner top-left"></div>
                <div class="panel-corner bottom-right"></div>
                <h3 class="stats-title">Aylık Katkı</h3>
                <strong class="stat-value accent" id="statMonthly">0</strong>
            </div>
            <div class="hud-panel stat-box">
                <div class="panel-corner top-left"></div>
                <div class="panel-corner bottom-right"></div>
                <h3 class="stats-title">Yıllık Katkı</h3>
                <strong class="stat-value success" id="statYearly">0</strong>
            </div>
        </section>

        <!-- Contribution Calendar -->
        <section class="hud-panel calendar-section" id="calendarSection" style="display: none;">
            <div class="panel-corner top-right"></div>
            <div class="panel-corner bottom-left"></div>
            <h3 class="section-title">VERİ AKIŞI: 365 GÜN</h3>
            <div class="calendar-wrapper">
                <div class="calendar-graph" id="calendarGraph">
                    <!-- Takvim JS ile çizilecek -->
                </div>
            </div>
            <div class="calendar-legend">
                <span>MİN</span>
                <ul class="legend-list">
                    <li style="background-color: var(--cal-level-0);"></li>
                    <li style="background-color: var(--cal-level-1);"></li>
                    <li style="background-color: var(--cal-level-2);"></li>
                    <li style="background-color: var(--cal-level-3);"></li>
                    <li style="background-color: var(--cal-level-4);"></li>
                </ul>
                <span>MAKS</span>
            </div>
        </section>

        <!-- Daily Stats & Timeline -->
        <div class="main-grid">
            <section class="hud-panel" id="statsSection" style="display: none;">
                <div class="panel-corner top-left"></div>
                <h3 class="section-title">GÜNLÜK RAPOR</h3>
                <ul class="stats-list">
                    <li><span class="stats-icon">▶</span> <strong id="statCommits">0</strong> İşlem Komutu</li>
                    <li><span class="stats-icon text-info" style="color: #0ff;">▶</span> <strong id="statChangedFiles">0</strong> Dosya Değiştirildi</li>
                    <li><span class="stats-icon text-success">▶</span> <strong id="statAdditions">0</strong> Veri
                        Eklendi</li>
                    <li><span class="stats-icon text-danger">▶</span> <strong id="statDeletions">0</strong> Veri Silindi
                    </li>
                    <li><span class="stats-icon text-accent">▶</span> <strong id="statRepos">0</strong> Modül
                        Güncellendi</li>
                    <li><span class="stats-icon text-warning">▶</span> <strong id="statWorkTime">0 Dakika</strong>
                        Sistem Süresi</li>
                </ul>

                <h3 class="section-title" style="margin-top: 30px;">AKTİF MODÜLLER</h3>
                <ul class="stats-list project-list" id="activeProjectsList">
                    <!-- Aktif projeler buraya yüklenecek -->
                </ul>
            </section>

            <section class="hud-panel activity-section">
                <div class="panel-corner bottom-right"></div>
                <h3 class="section-title">SİSTEM LOGLARI</h3>
                <div id="activityTimeline" class="timeline">
                    <!-- JavaScript ile yüklenecek -->
                    <div class="loading-state">
                        <div class="spinner"></div>
                        <p>VERİLER ÇEKİLİYOR...</p>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- Global Tooltip -->
    <div id="globalTooltip" class="global-tooltip"></div>

    <script src="themes/jarvis/assets/js/app.js"></script>
</body>

</html>